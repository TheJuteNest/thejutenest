# The Jute Nest Website

This is the official website for **The Jute Nest** — a jute bag business based in Howrah, West Bengal.

## Pages Included:
- Home
- About Us
- Products/Services
- Gallery
- Contact

## Contact:
📞 Phone: 8436972792  
📧 Email: thejutenest@gmail.com  
📍 Address: Howrah, West Bengal - 711202  
📱 Social: @thejutenest on Instagram, YouTube, Facebook
